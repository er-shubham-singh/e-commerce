import React from 'react'
import { IoMdMenu } from "react-icons/io";



export default function Header() {
  return (
    <div>
      <div className=' top-0 '>
      <div className=' max-w-[1320px] mx-auto flex justify-between ' >
        <div className=''><img src="https://staging.adiyogitechnology.com/sushmagroup/assets/Group%203960-BLB6eVGP.png" alt="" /></div>
        <div>
            <div></div>
            <div><IoMdMenu /></div>
        </div>
      </div>
      </div>
    </div>
  )
}
